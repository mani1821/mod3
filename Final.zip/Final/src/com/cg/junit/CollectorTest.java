package com.cg.junit;
import static org.junit.Assert.*;

//import org.junit.Test;
import org.junit.*;

import com.capgemini.bin.*;
import com.capgemini.collection.*;
import com.capgemini.exception.*;
import com.capgemini.validator.*;
import org.junit.runners.*;

//Running test cases in order of method names in ascending order

public class CollectorTest {

	@Test
	public void testadd()
	{
		Collector.adddetails(new ItemSchema(123,"mani",789,8956));
		Assert.assertEquals("Fail", 4,Collector.count_records()); 
	}
	@Test
	public void testremove()
	{
		Collector.remove_by_id(15);
		Assert.assertEquals("Fail", 3,Collector.count_records()); 
	}
	@Test
	public void testcount()
	{
		Assert.assertEquals("Fail", 3,Collector.count_records()); 
	}
}
