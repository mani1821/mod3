
import java.util.regex.*;
import java.util.*;

import static java.lang.System.out;
public class Pattern_match {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner cin=new Scanner(System.in);
		String input;
		out.println("Enter user name");
		input=cin.nextLine();
		String ptrn="[A-Z][A-Za-z0-9]{6,15}";
		Pattern pt=Pattern.compile(ptrn);
		Matcher m = pt.matcher(input);
		if(m.find())
		{
			out.println("Valid Username");
		}
		else
		{
			out.println("Invalid username");
		}
		
	}

}
