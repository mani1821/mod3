
public class TrialDerived1 extends TrialBase {
@Override
	public void method1() {System.out.println("Derived1 Method1");}
	
	//public abstract void method1(); 
	
	}


