package javafun;
import java.util.*;
class Tbl{
	
}
public class Table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner c=new Scanner(System.in);
		System.out.println("Enter number");
		int k=c.nextInt();
		for(int i=1;i<=10;i++)
		{
			System.out.println(k+" X "+i+" = "+(k*i));
			
		}
	}

}
