package javafun;
import java.util.*;
public class Jav {
public static void main(String args[])
{
	
	Scanner c=new Scanner(System.in);
	System.out.println("Enter number");
	int k=c.nextInt();
	if(k%2==0)
	{
		System.out.println();
	}
	else
	{
		System.out.println(k+" is odd");
	}
	
}
}
