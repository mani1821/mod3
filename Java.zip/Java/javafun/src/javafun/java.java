package javafun;

public class java {

}
