package com.capgemini.lesson3.operators;

public class forchar {
	public static void main(String args[]){
		char c;
		String w="mani";
		for(char c:w)
		{
			
		}
	}

}
