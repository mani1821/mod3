package com.capgemini.lesson6.useoffinal.finalinside;

public class Base1 {

}
