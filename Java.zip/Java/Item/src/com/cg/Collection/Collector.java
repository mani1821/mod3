package com.cg.Collection;

public class Collector {

}
