package com.cg.ui;
import com.cg.bin.ItemSchema;
import com.cg.exception.*;
import com.cg.helper.*;
import com.cg.Collection.*;
import java.util.*;
import static java.lang.System.out;
public class ItemUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int choice;
Scanner cin=new Scanner(System.in);
  while(true)
{
	out.println("Enter your choice");
	out.println("1----Add Details");
	out.println("2----Display Details");
	out.println("3---- Count Of Records");
	out.println("4----Delete Record");
	out.println("5----Exit");
	
	choice=cin.nextInt();
	switch(choice)
	{
	case 1:{System.out.println("Add Details");
	//adddetails();
		break;}
	
	case 2:{System.out.println("Diplay Details");
	//ob.display();
	break;}
	case 3:{System.out.println("Delete Details");
	//ob.delete();
	break;}
	case 4:{System.out.println("Find Details");
	//ob.findCount();
	break;}
	case 5:{System.exit(0);
	break;}
	default:{System.out.println("Enter proper option");
	break;}
	}
	
}
	}
public static void AddDetails()
{
	
}
}

