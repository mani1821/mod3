package  src.com.capgemini.paymobbill.exception;

@SuppressWarnings("serial")
public class InvalidNumberException extends Exception {
	public InvalidNumberException() {
		
		System.out.println("*********************************ERROR*************************************");
		
	}
}
