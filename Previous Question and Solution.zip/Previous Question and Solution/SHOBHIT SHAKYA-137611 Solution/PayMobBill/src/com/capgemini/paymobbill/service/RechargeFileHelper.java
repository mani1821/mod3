package com.capgemini.paymobbill.service;								// NAME OF THE PACKAGE 

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;												// NECESSARY IMPORTS 
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import com.capgemini.paymobbill.bean.RechargeDetails;

public class RechargeFileHelper											// CLASS RECHARGEFILEHELPER	
{
	public void fileWrite(RechargeDetails obj) {						//METHOD TO WRITE THE USER DETAILS ONTO THE FILE	
		try {															// EXCEPTION HANDLING
			ObjectOutputStream OoS = new ObjectOutputStream(new FileOutputStream("resources/abc.txt"));
			OoS.writeObject(obj);
			OoS.close();
		} catch (FileNotFoundException e) {													
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public void readFile() {											// METHOD TO READ THE USER DETAILS FROM THE FILE
		try {															// EXCEPTION HANDLING 
			ObjectInputStream OiS = new ObjectInputStream(new FileInputStream("resources/abc.txt"));
			try {
				System.out.println(OiS.readObject());
				OiS.close();
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
	}

	
}
